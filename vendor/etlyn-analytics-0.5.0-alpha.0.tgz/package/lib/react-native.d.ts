import { type FirstPartyOptions, type AnalyticsStorage, type EventProperties } from "./first-party.js";
export interface NativeAnalyticsOptions extends Omit<FirstPartyOptions, "platform" | "collectionMode" | "storage" | "randomUUID"> {
    platform: "ios" | "android";
    storage: AnalyticsStorage;
    randomUUID: () => string;
    screens: readonly string[];
    appState: {
        currentState: string | null;
        addEventListener(event: "change", listener: (state: string) => void): {
            remove(): void;
        };
    };
    subscribeReconnect?: (listener: () => void) => () => void;
}
/** One instance per app. No React, navigation, user IDs or device identifiers are required. */
export declare function createReactNativeAnalytics(options: NativeAnalyticsOptions): {
    start: () => Promise<void>;
    flush: () => Promise<void>;
    setEnabled: (value: boolean) => Promise<void>;
    screen: (name: string | undefined) => Promise<void>;
    isEnabled: () => boolean;
    subscribe(listener: () => void): () => void;
    track(name: string, properties?: EventProperties): Promise<void>;
    reset(): Promise<void>;
    stop(): Promise<void>;
};
//# sourceMappingURL=react-native.d.ts.map