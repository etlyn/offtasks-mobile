import type { EventProperties } from "./first-party.js";
/** Public canonical page only: never query strings, fragments or credentials. */
export declare function canonicalPageUrl(value: string): string | undefined;
/** Attribution labels only; no click IDs, search terms or referring page URLs. */
export declare function webAttribution(value: string, referrer?: string): EventProperties;
//# sourceMappingURL=web-attribution.d.ts.map