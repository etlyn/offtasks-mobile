export interface WebsiteAnalyticsOptions {
    applicationKey?: string;
    apiBaseUrl?: string;
    appVersion: string;
    screenForPath: (pathname: string) => string | null;
    clickTargets?: readonly string[];
}
/** Cookieless public-site integration shared by Etlyn tenant websites. */
export declare function createWebsiteAnalytics(options: WebsiteAnalyticsOptions): {
    configured: boolean;
    preferenceKey: string;
    privacySignalActive: () => boolean;
    readEnabled: () => boolean;
    setEnabled: (value: boolean) => void;
    recordConversion: (name: "contact_submit" | "newsletter_subscribe") => void;
    recordPage: () => void;
    start: () => () => void;
};
//# sourceMappingURL=website.d.ts.map