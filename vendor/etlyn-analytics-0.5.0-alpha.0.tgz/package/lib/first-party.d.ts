export declare const FIRST_PARTY_VERSION = "0.5.0-alpha.0";
export type AnalyticsPlatform = "web" | "ios" | "android" | "macos" | "windows" | "linux" | "unknown";
export type EventProperties = Record<string, string | number | boolean | null>;
export interface AnalyticsStorage {
    getItem(key: string): string | null | Promise<string | null>;
    setItem(key: string, value: string): void | Promise<void>;
    removeItem(key: string): void | Promise<void>;
}
export interface FirstPartyOptions {
    applicationKey: string;
    apiBaseUrl: string;
    platform: AnalyticsPlatform;
    allowedEvents: Record<string, readonly string[]>;
    appVersion?: string;
    policyVersion?: "1" | "2";
    collectionMode?: "consent" | "cookieless" | "native-opt-out";
    storage?: AnalyticsStorage;
    fetch?: typeof fetch;
    now?: () => number;
    randomUUID?: () => string;
    permitted?: () => boolean;
    withLock?: (operation: () => Promise<void>) => Promise<void>;
}
export declare class FirstPartyAnalytics {
    private readonly options;
    private consent;
    private generation;
    private pending;
    private memory;
    private controller?;
    private retryAt;
    private failures;
    private disabled;
    private configAt;
    private remoteEvents?;
    private readonly key;
    private readonly now;
    private readonly request;
    constructor(options: FirstPartyOptions);
    private allowed;
    private serial;
    setConsent(granted: boolean): Promise<void>;
    /** Enable/disable collection; cookieless mode never asserts consent. */
    setEnabled(granted: boolean): Promise<void>;
    /** Stop delivery without withdrawing consent or deleting the offline queue. */
    pause(): Promise<void>;
    reset(): Promise<void>;
    private clear;
    private validProperties;
    private state;
    private save;
    track(name: string, properties?: EventProperties): Promise<void>;
    screen(screen: string): Promise<void>;
    flush(): Promise<void>;
}
export declare function createBrowserAnalytics(options: Omit<FirstPartyOptions, "platform" | "storage" | "withLock" | "permitted">): FirstPartyAnalytics;
export { webAttribution, canonicalPageUrl } from "./web-attribution.js";
//# sourceMappingURL=first-party.d.ts.map