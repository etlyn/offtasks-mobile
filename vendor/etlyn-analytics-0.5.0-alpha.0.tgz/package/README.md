# @etlyn/analytics

Planned work: [landing-page rollout assessment and checklist](TODO.md).

## First-party analytics

The `@etlyn/analytics/first-party` entry point sends only to Etlyn's versioned
FastAPI collector. It does not load Google or Vercel analytics. The root entry point exports the same first-party SDK. There are no third-party transports.

```ts
import { createBrowserAnalytics } from "@etlyn/analytics/first-party";

const analytics = createBrowserAnalytics({
  applicationKey: "registered-public-application-key",
  apiBaseUrl: "https://api.etlyn.com",
  appVersion: "1.0.0",
  allowedEvents: { page_view: ["screen"], click: ["screen", "target"] },
});

await analytics.setConsent(true);
await analytics.screen("home");
await analytics.track("click", { screen: "home", target: "contact" });
await analytics.flush();
```

Call `setConsent(true)` only after permission. Consent defaults to denied; the
browser adapter also respects DNT and Global Privacy Control. Revocation clears
queued events and identifiers and aborts active delivery, but cannot recall an
event the server already committed. `reset()` clears identity and the queue.

Events are limited to configured names/properties, 500 queued records, seven days
of offline retention, and 25 records per flush. Call `flush()` periodically and
on reconnect/page hide. A successful receipt removes delivered records; transient
errors retain their IDs for deduplication. Invalid batches are discarded, and
server disablement clears the queue. Persistence failure falls back to memory.
Browser Web Locks coordinate tabs when available; older browsers without Web
Locks do not guarantee loss-free concurrent localStorage updates.

`FirstPartyAnalytics` is the platform-neutral core. Native consumers must supply
an async storage adapter and call `screen`, `flush`, and consent methods from
their lifecycle/navigation integration. A React Native pilot adapter is now available; see below for its collection
policy and lifecycle contract. Swift/Kotlin packaging and real-device
certification remain follow-up work.

Country/city and browser/device enrichment happens at the server. Do not send
IP addresses, geolocation, user agent strings, private URL parameters, form values, or document
content as event properties. IP-based location describes upload location, may
be Unknown, and is not precise GPS or proof of a person's residence.

Run `npm test` on Node 24. The pilot is consumed as a versioned package archive
until its prerelease is explicitly published.

## Public page URLs and acquisition attribution

Version 0.3 adds `canonicalPageUrl(url)` and `webAttribution(url, referrer)`
from `@etlyn/analytics/first-party`. The first keeps only origin and pathname;
the second returns bounded source, medium, campaign and referring-domain labels.
It never retains query strings, fragments, click IDs, referring page paths or
search terms. Only call these for public routes and store attribution after
consent. Consumers own session expiry and clear attribution on withdrawal.

Use `policyVersion: "2"` with renewed consent and include `page_url`, `source`,
`medium`, `campaign` and `referrer_host` in both client and server event allowlists.
Track a page with `track("page_view", { screen, page_url, ...attribution })`.
Generic `screen(name)` remains available for basic web/native integrations.


## Cookieless web analytics (recommended for Etlyn tenant websites)

Pass `collectionMode: "cookieless"` to `createBrowserAnalytics`. It starts enabled,
uses no analytics cookies, localStorage or sessionStorage, and keeps random client
and session identifiers and queued events only in memory. Reloading starts a new
client instance. Call `setEnabled(false)` for an opt-out and persist only that
preference in the product, with an accessible control in its privacy policy.
Do Not Track and Global Privacy Control still prevent collection.

Cookieless batches use policy 3 and `consent: "not_requested"`; they never claim
that a visitor consented. The default remains explicit-consent mode for existing
integrations. Never add `setConsent(true)` merely to hide a banner. Explain the
collection purpose, data fields, 400-day server retention, and opt-out in each
product's privacy policy. No cross-site identity or persistent returning-visitor
measurement is supported in cookieless mode.

## Shared tenant website adapter

`createWebsiteAnalytics` from `@etlyn/analytics/website` provides the Etlyn.com
cookieless lifecycle for tenant websites. Supply a public `screenForPath` allowlist,
application key, collector URL and app version. Call `start()` once at bootstrap
and dispose it during hot reload. It observes history navigation without adding
a router, deduplicates page views, records recognized navigation/contact/social
links and explicitly allowed `data-analytics-target` values, and flushes events.

Use `setEnabled`, `readEnabled`, `privacySignalActive` and `preferenceKey` for
privacy controls. `recordConversion("contact_submit" | "newsletter_subscribe")`
is only for confirmed successful submissions; allow those names in the server
application registry. Do not pass form fields. Unknown/private routes are excluded
from views, clicks and conversions. Host privacy policies must describe collection.

## React Native pilot

`createReactNativeAnalytics` from `@etlyn/analytics/react-native` connects the
shared collector to an injected async storage adapter, secure UUID generator and
React Native AppState. Supply a separate registered iOS/Android application key,
app version, fixed screen names and allowed events. Start one instance at the
navigation root; call `screen` only with a mapped route name, never route params.
Call custom events only after the underlying action succeeds.

Native policy 4 uses `consent: "not_requested"`, with a saved opt-out. Startup
waits for the preference; unreadable preferences fail closed. This is distinct
from memory-only web policy 3: native random installation IDs and offline events
persist on the device. No account ID or advertising ID is used. Document this
behavior and provide an accessible in-app control. Withdrawal clears the local
queue and identity; `stop()` pauses delivery while preserving pending events.
Re-enabling starts a new identity after withdrawal.

Foreground/background changes and a 15-second foreground timer attempt delivery;
`subscribeReconnect` optionally provides immediate network restoration delivery.
The OS may suspend background execution; the queue retries on reopening. Queues
retain at most 500 events for seven days, with original event times and IDs.
Server storage remains 400 days. App versions are captured per event.

The Offtasks integration is the first consumer. Native build/device validation is
recorded in TODO.md; this is not a claim of App Store publication or certification.
