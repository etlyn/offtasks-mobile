export interface ValidateReturnPathOptions {
    allowedOrigins?: readonly string[];
    fallback: string;
}
export declare function validateReturnPath(candidate: string | null | undefined, options: ValidateReturnPathOptions): string;
//# sourceMappingURL=return-path.d.ts.map