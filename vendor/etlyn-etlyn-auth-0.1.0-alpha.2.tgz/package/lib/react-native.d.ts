export interface SecureStoreLike {
    getItem?(key: string): Promise<string | null> | string | null;
    setItem?(key: string, value: string): Promise<void> | void;
    removeItem?(key: string): Promise<void> | void;
    getItemAsync?(key: string): Promise<string | null>;
    setItemAsync?(key: string, value: string): Promise<void>;
    deleteItemAsync?(key: string): Promise<void>;
}
export interface DeepLinkSupabaseClientLike {
    auth: {
        exchangeCodeForSession?: (code: string) => Promise<{
            data?: unknown;
            error?: {
                status?: number;
                message?: string;
            } | null;
        }>;
    };
}
export interface DeepLinkHandlerOptions {
    supabase: DeepLinkSupabaseClientLike;
    validateUrl: (url: URL) => boolean;
}
/** Use a native secure store that supports full session values (e.g. Keychain).
 * Chunking is deliberately avoided: a partial write must not destroy a session.
 */
export declare function createSecureStorageAdapter(store: SecureStoreLike): {
    getItem: (key: string) => Promise<string | null>;
    setItem: (key: string, value: string) => Promise<void>;
    removeItem: (key: string) => Promise<void>;
};
/** Move only SDK-owned keys from legacy storage after a successful secure write. */
export declare function createMigratingSecureStorageAdapter(secureStore: SecureStoreLike, legacyStore: SecureStoreLike): {
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
};
export declare function createDeepLinkHandler(options: DeepLinkHandlerOptions): (value: string | URL) => Promise<boolean>;
//# sourceMappingURL=react-native.d.ts.map