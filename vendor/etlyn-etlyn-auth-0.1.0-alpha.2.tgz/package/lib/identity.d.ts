import type { AccessTokenProvider } from './fetch.js';
import type { AuthMembership } from './session.js';
export interface IdentityUser {
    id: string;
    email?: string;
    displayName?: string;
}
export interface IdentityDescriptor {
    provider: string;
    subject: string;
    assurance?: string;
}
export interface IdentityMe {
    linked: boolean;
    user: IdentityUser;
    identity: IdentityDescriptor | null;
    memberships: readonly AuthMembership[];
    activeCompanyId: string | null;
    platformAdmin: boolean;
    capabilities: readonly string[];
}
export interface IdentityClientOptions {
    baseUrl: string | URL;
    getAccessToken: AccessTokenProvider;
    fetch?: typeof globalThis.fetch;
    companyId?: string;
}
export declare function createIdentityClient(options: IdentityClientOptions): {
    getMe(): Promise<IdentityMe>;
};
//# sourceMappingURL=identity.d.ts.map