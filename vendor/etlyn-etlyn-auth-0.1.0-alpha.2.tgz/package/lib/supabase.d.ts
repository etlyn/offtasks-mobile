import type { IdentityMe } from './identity.js';
import type { AccessTokenProvider } from './fetch.js';
import type { AuthAdapter } from './session.js';
export interface SupabaseAuthErrorLike {
    message?: string;
    status?: number;
}
export interface SupabaseSessionLike {
    access_token?: string | null;
    user?: {
        id?: string | null;
        email?: string | null;
        user_metadata?: Record<string, unknown> | null;
    } | null;
}
export interface SupabaseClientLike {
    auth: {
        getSession(): Promise<{
            data?: {
                session: SupabaseSessionLike | null;
            } | null;
            error?: SupabaseAuthErrorLike | null;
        }>;
        signInWithPassword(credentials: {
            email: string;
            password: string;
        }): Promise<{
            data?: {
                session: SupabaseSessionLike | null;
            } | null;
            error?: SupabaseAuthErrorLike | null;
        }>;
        refreshSession?: () => Promise<{
            data?: {
                session: SupabaseSessionLike | null;
            } | null;
            error?: SupabaseAuthErrorLike | null;
        }>;
        signOut(): Promise<{
            error?: SupabaseAuthErrorLike | null;
        }>;
        onAuthStateChange(callback: (event: string, session: SupabaseSessionLike | null) => void): {
            data?: {
                subscription: {
                    unsubscribe(): void;
                };
            } | null;
        } | {
            subscription: {
                unsubscribe(): void;
            };
        };
        signInWithOAuth?: (...args: readonly unknown[]) => unknown;
        resetPasswordForEmail?: (...args: readonly unknown[]) => unknown;
        exchangeCodeForSession?: (code: string) => Promise<{
            data?: unknown;
            error?: SupabaseAuthErrorLike | null;
        }>;
    };
}
export interface SupabaseIdentityClientLike {
    getMe(): Promise<IdentityMe>;
}
export interface RedirectToBuilderOptions {
    origin: string | URL;
    callbackPath?: string;
    returnPathParameter?: string;
    allowedOrigins?: readonly string[];
    fallback?: string;
}
export interface SupabaseAuthAdapter<Credentials = {
    email: string;
    password: string;
}> extends AuthAdapter<Credentials> {
    getAccessToken: AccessTokenProvider;
}
export interface CreateSupabaseAuthAdapterOptions {
    supabase: SupabaseClientLike;
    identity: SupabaseIdentityClientLike;
}
export declare function createRedirectToBuilder(options: RedirectToBuilderOptions): (candidate: string | null | undefined) => string;
export declare function createSupabaseAuthAdapter(options: CreateSupabaseAuthAdapterOptions): SupabaseAuthAdapter;
//# sourceMappingURL=supabase.d.ts.map