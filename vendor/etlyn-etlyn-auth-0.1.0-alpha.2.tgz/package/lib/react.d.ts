import React from 'react';
import { type CapabilitySet } from './capabilities.js';
import { type AuthAdapter, type AuthSession } from './session.js';
export * from './session.js';
/** Keep adapter identity stable. No CSS, router, CMS store or persistence is imported. */
export declare function AuthProvider({ adapter, children }: {
    adapter: AuthAdapter;
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function useAuth<Credentials = unknown>(): {
    refresh: () => Promise<void>;
    signIn: (credentials: Credentials) => Promise<void>;
    signOut: () => Promise<void>;
    status: "checking" | "authenticated" | "anonymous" | "error";
    session: AuthSession | null;
    pending: "refresh" | "signIn" | "signOut" | null;
    error: string | null;
};
export declare function useSession(): AuthSession | null;
export declare function useCapabilities(): CapabilitySet;
export declare function useMembership(): {
    memberships: readonly import("./session.js").AuthMembership[];
    activeCompanyId: string | null;
    activeMembership: import("./session.js").AuthMembership | null;
};
//# sourceMappingURL=react.d.ts.map