export type AuthErrorCode = 'unauthorized' | 'identity_not_linked' | 'company_not_permitted' | 'mfa_required' | 'identity_provider_unavailable' | 'service_unavailable' | 'invalid_response' | 'callback_not_allowed';
export interface AuthServiceErrorOptions {
    code?: AuthErrorCode;
    status?: number;
}
export declare class AuthServiceError extends Error {
    readonly code: AuthErrorCode;
    readonly status: number | null;
    constructor(message?: string, options?: AuthServiceErrorOptions);
}
export declare class IdentityNotLinkedError extends AuthServiceError {
    constructor(message?: string);
}
export declare class CompanyNotPermittedError extends AuthServiceError {
    constructor(message?: string);
}
export declare class MfaRequiredError extends AuthServiceError {
    constructor(message?: string);
}
//# sourceMappingURL=errors.d.ts.map