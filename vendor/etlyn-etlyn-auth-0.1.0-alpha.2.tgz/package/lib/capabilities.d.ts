export interface CapabilitySet {
    readonly names: readonly string[];
    has(name: string): boolean;
    hasAny(...names: readonly string[]): boolean;
    hasAll(...names: readonly string[]): boolean;
}
export declare function capabilitiesOf(source: {
    capabilities: readonly string[];
} | null | undefined): CapabilitySet;
//# sourceMappingURL=capabilities.d.ts.map