export interface AccessTokenRequest {
    refresh?: boolean;
}
export type AccessTokenProvider = (request?: AccessTokenRequest) => Promise<string | null | undefined> | string | null | undefined;
export interface AuthenticatedFetchOptions {
    baseUrl: string | URL;
    getAccessToken: AccessTokenProvider;
    fetch?: typeof globalThis.fetch;
    companyId?: string;
    onUnauthorized?: (response: Response) => Promise<void> | void;
}
export declare function createAuthenticatedFetch(options: AuthenticatedFetchOptions): (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
//# sourceMappingURL=fetch.d.ts.map