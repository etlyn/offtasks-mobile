import type { AuthAdapter, AuthMembership } from './session.js';
export interface CookieAuthOptions<Credentials extends Record<string, unknown> = Record<string, unknown>> {
    baseUrl?: string | URL;
    fetch?: typeof globalThis.fetch;
    getSessionPath?: string;
    signInPath?: string;
    signOutPath?: string;
    mapRoleToCapabilities?: (role: string, context: {
        user: Record<string, unknown>;
        membership: AuthMembership | null;
    }) => readonly string[];
}
export declare function createCookieAuthAdapter<Credentials extends Record<string, unknown> = Record<string, unknown>>(options?: CookieAuthOptions<Credentials>): AuthAdapter<Credentials>;
//# sourceMappingURL=cookie.d.ts.map