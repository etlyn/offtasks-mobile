/** Provider-neutral session state. Transport, persistence and navigation belong to the host. */
export interface AuthUser {
    id: string;
    displayName?: string;
}
export interface AuthMembership {
    companyId: string;
    role: string;
    apps: readonly string[];
    status: 'active' | 'suspended' | 'removed' | (string & {});
}
export interface AuthSession {
    linked: boolean;
    user: AuthUser;
    memberships: readonly AuthMembership[];
    activeCompanyId: string | null;
    platformAdmin: boolean;
    capabilities: readonly string[];
}
export interface AuthAdapter<Credentials = unknown> {
    getSession(): Promise<AuthSession | null>;
    signIn(credentials: Credentials): Promise<AuthSession>;
    signOut(): Promise<void>;
}
export type AuthState = {
    status: 'checking' | 'authenticated' | 'anonymous' | 'error';
    session: AuthSession | null;
    pending: 'refresh' | 'signIn' | 'signOut' | null;
    error: string | null;
};
export declare function createAuthClient<Credentials>(adapter: AuthAdapter<Credentials>): {
    getSnapshot: () => AuthState;
    subscribe: (listener: () => void) => () => void;
    refresh: () => Promise<void>;
    signIn: (credentials: Credentials) => Promise<void>;
    signOut: () => Promise<void>;
    cancelPending: () => void;
};
//# sourceMappingURL=session.d.ts.map