# @etlyn/etlyn-auth

Independent repository: `etlyn/etlyn-auth`, published as `@etlyn/etlyn-auth`.
Use Node 24 and `yarn install`, then run `npm run typecheck` and `npm test` from this root.
Publishing is an explicit workflow after version review.

`@etlyn/etlyn-auth` is Etlyn's thin, headless auth client for browser, React Native, and same-origin cookie hosts. It owns no UI, CSS, routing, tokens, or CMS imports.

## Entry points

- `@etlyn/etlyn-auth`: provider-neutral session state, typed identity/fetch helpers, return-path validation, typed errors.
- `@etlyn/etlyn-auth/react`: `AuthProvider`, `useAuth`, `useSession`, `useCapabilities`, `useMembership`.
- `@etlyn/etlyn-auth/cookie`: same-origin HttpOnly cookie adapter for hosts like E2E.
- `@etlyn/etlyn-auth/supabase`: structural Supabase adapter plus a safe redirect-to builder.
- `@etlyn/etlyn-auth/react-native`: secure-storage adapter and PKCE deep-link handler.

Peer dependencies stay optional so core installs no React, React Native, or Supabase runtime.

## Core usage

```ts
import {
  createAuthClient,
  createAuthenticatedFetch,
  createIdentityClient,
  validateReturnPath,
} from '@etlyn/etlyn-auth';

const tokenProvider = {
  async read() {
    return null;
  },
};

const returnTo = validateReturnPath(new URL(window.location.href).searchParams.get('returnTo'), {
  allowedOrigins: [window.location.origin],
  fallback: '/',
});

const identity = createIdentityClient({
  baseUrl: 'https://api.etlyn.com',
  getAccessToken: () => tokenProvider.read(),
  companyId: 'tenant-company',
});

const authFetch = createAuthenticatedFetch({
  baseUrl: 'https://api.etlyn.com',
  getAccessToken: async ({ refresh } = {}) => {
    if (refresh) await refreshTokenSomewhereElse();
    return tokenProvider.read();
  },
  companyId: 'tenant-company',
});
```

## React web host with Supabase

```tsx
import { createIdentityClient } from '@etlyn/etlyn-auth';
import { AuthProvider, useAuth, useCapabilities } from '@etlyn/etlyn-auth/react';
import { createRedirectToBuilder, createSupabaseAuthAdapter } from '@etlyn/etlyn-auth/supabase';

const identity = createIdentityClient({
  baseUrl: 'https://api.etlyn.com',
  getAccessToken: async () => {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token ?? null;
  },
  companyId: 'tenant-company',
});

const adapter = createSupabaseAuthAdapter({ supabase, identity });
const redirectTo = createRedirectToBuilder({
  origin: window.location.origin,
  callbackPath: '/auth/callback',
  fallback: '/',
});

function AccountGate() {
  const { status, signIn, signOut } = useAuth<{ email: string; password: string }>();
  const capabilities = useCapabilities();

  if (status === 'anonymous') {
    return (
      <button onClick={() => signIn({ email: 'name@example.com', password: 'secret' })}>
        Sign in
      </button>
    );
  }

  return (
    <div>
      <p>{capabilities.has('company:admin') ? 'Admin' : 'Member'}</p>
      <button onClick={() => signOut()}>Sign out</button>
    </div>
  );
}

<AuthProvider adapter={adapter}>
  <AccountGate />
</AuthProvider>;

await supabase.auth.signInWithOAuth?.({
  provider: 'google',
  options: { redirectTo: redirectTo('/settings') },
});
```

## Cookie-session host

```ts
import { createAuthClient } from '@etlyn/etlyn-auth';
import { createCookieAuthAdapter } from '@etlyn/etlyn-auth/cookie';

const adapter = createCookieAuthAdapter<{ username: string; password: string }>({
  mapRoleToCapabilities(role) {
    return role === 'admin' ? ['company:admin'] : ['company:editor'];
  },
});

const auth = createAuthClient(adapter);
await auth.refresh();
await auth.signIn({ username: 'editor', password: 'correct horse battery staple' });
```

## Expo / React Native host

```ts
// Use a full-value native Keychain adapter; see the Offtasks host example.
import { createDeepLinkHandler, createSecureStorageAdapter } from '@etlyn/etlyn-auth/react-native';

const storage = createSecureStorageAdapter({
  getItem: nativeKeychain.getItem,
  setItem: nativeKeychain.setItem,
  removeItem: nativeKeychain.removeItem,
});

const handleDeepLink = createDeepLinkHandler({
  supabase,
  validateUrl(url) {
    return url.protocol === 'myapp:' && url.hostname === 'auth';
  },
});

await storage.setItem('sb-auth-token', '{"access_token":"example"}');
await handleDeepLink('myapp://auth/callback?code=pkce-code');
```

## Development scripts

- `npm run typecheck`: strict TypeScript checks.
- `npm run build`: compile ESM + declarations into `lib/`.
- `npm test`: rebuild and run the Node test suite.

## Validation and behavior notes

- The core state machine preserves stale-request invalidation, duplicate-mutation suppression, explicit service failures, and client isolation from the original CMS boundary.
- `createAuthenticatedFetch` retries only once after a 401 refresh and never sends Etlyn auth headers off-origin.
- The React hooks expose normalized user/session data only: no raw tokens or provider metadata.
- Supabase remains the session owner; this library never persists tokens itself.

## License

MIT

Secure storage must support full session values. `createMigratingSecureStorageAdapter` moves SDK-owned keys only after a successful secure write; planner data stays in its existing store.
