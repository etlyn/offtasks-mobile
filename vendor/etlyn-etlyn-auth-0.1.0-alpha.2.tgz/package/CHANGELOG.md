# 0.1.0-alpha.2

First registry rollout. Refresh requests call the provider refresh API. Native secure storage uses full-value Keychain persistence; legacy sessions move only after a successful secure write.

# Changelog

## 0.1.0-alpha.1 - 2026-10-04

- added `typesVersions` so TypeScript projects using `moduleResolution: node` resolve the `/react`, `/cookie`, `/supabase` and `/react-native` subpaths

## 0.1.0-alpha.0 - 2026-10-03

- extracted the provider-neutral auth session state machine from the CMS boundary into a standalone package
- added typed identity and authenticated-fetch helpers for the Etlyn `/identity/me` contract
- added React, cookie-session, Supabase, and React Native entry points without UI or routing concerns
- added deterministic unit coverage for stale requests, duplicate mutations, identity error mapping, refresh-once fetch, secure-storage chunking, and deep-link PKCE handling
